[{
    "Id": 25106,
    "Text": "Có mấy loại Service?",
    "Marks": 1,
    "AnswerId": 104121,
    "Answers":
        [{
            "Id": 104118,
            "Text": "3"
        },
        {
            "Id": 104119,
            "Text": "4"
        },
        {
            "Id": 104120,
            "Text": "1"
        },
        {
            "Id": 104121,
            "Text": "2"
        }]
}]